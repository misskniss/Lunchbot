#!/usr/bin/env python

import ros
import roslaunch
import rospy
import roslib
import tf
import argparse
import actionlib
import get_position
import subprocess
import os
import serial
import time
from actionlib_msgs.msg import *
from EggVisionWIP import EggVisionWIP
from geometry_msgs.msg import Pose, PoseWithCovarianceStamped, Point, Quaternion, Twist
from JensMoveIt import MoveIt
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from nav_msgs.msg import Odometry
from serial_test import SerialTest
from sys import executable


class EggHunter():

    def __init__(self, field, basket):

        self.FIELD_EDGE = field
        self.BASKET = basket
        self.MAX = 15.0
        self.STATE = 0
        print "Field location set to: " + str(self.FIELD_EDGE)
        print "Basket location set to: " + str(self.BASKET)

        self.kobuki = MoveIt()
        #self.position = kobuki.get_position()
        self.position = (0.0,0.0)
        
        #rospy.init_node('Egg_Hunt', anonymous=False)
        rospy.on_shutdown(self.shutdown)
    
    def go_to(self, target):
        print "going to: " + str(target)
        if (target[0] != 0):
            self.kobuki.horizontal(target[0])
        if (target[1] != 0):
            self.kobuki.forward(target[1])
        x_val = self.position[0]
        x_val += target[0]
        y_val = self.position[1]
        y_val += target[1]
        self.position = (x_val, y_val)
        print "my position is now: " + str(self.position)
     
    def go_to_field(self):
        self.go_to_basket()
        print "Heading to field..."
        self.go_to(self.FIELD_EDGE)
        print "At field."
    
    def go_to_basket(self):
        print "Calculating backet location..."
        x_val = self.position[0] * -1
        y_val = self.position[1] * -1
        new_position = (x_val, y_val)
        self.go_to(new_position)

        print "Heading to basket..."
        self.go_to(self.BASKET)
        print "At Basket."

    def set_state(self, value):
        self.state = value
        
    def get_state(self):
        return self.state
    
    """ Uses the vision analysis instance to find
        a set of x,y distances in meters """
    def identify(self):
        
        print "Identifying... "
        ev = EggVisionWIP()
        distances = (-1,-1)
        r=rospy.Rate(10)
        time_start = rospy.get_time()
        time_now = rospy.get_time()
        
        print("Searching...")
        while (distances[0] == -1 and not rospy.is_shutdown()):    
            time_now=rospy.get_time()
            if (time_now-time_start > 10):
                # restart the current time after forward call & 10 seconds and 
                time_start=rospy.get_time() 
                print("No egg in sight, I'm outta here")
                # maintain 15 meter boundary
                if (self.position[1] + 0.5 < 15.0): 
                    distTraveled=self.kobuki.forward(0.5)
                    if(distTraveled != -1):
                        print("Egg acquired!!! Now going back to home base")
                        self.position[1] += distTraveled
                    else:
                        self.position[1] += 0.5
                else: 
                    # go back 10 meters and turn right 1 meter
                    # to check for new eggs in the location
                    distTraveled=self.kobuki.forward(-10)
                    if(distTraveledi != -1): 
                        #If egg is detected, go home
                        print("Egg acquired!!! Going home now!")
                        self.position[1] += distTraveled * -1
                    else:
                        self.position[1] -= 10 #this is not how you add tuples
                        # Kevin, try pulling out the variable you want from the 
                        # tuple first (x_val = self.position[0]), manipulate it
                        # then set self.position all at once.
                    self.kobuki.horizontal(1)
                    self.position[0] += 1
            distances=ev.getDistance()
            r.sleep()

        print "New Deltas: " + str(distances)
        return distances

    def shutdown(self):
        rospy.loginfo("Stopping the hunt.")

    def dummy(self, string):
        print string

if __name__ == '__main__':
    
    # These need to be coded for each map you make
    field_edge = (0.0, 0.5)
    basket = (0.0, 0.0)
    egg_location = 0.0
    position = (0.0, 0.0)
    #rospy.init_node('Egg_Hunt', anonymous=False)
    
    hunter = EggHunter(field_edge, basket)
    serial = SerialTest()

    state = serial.read()
    print "Start. State is: " + state
    while (state != None):
        if state is "44":
            state = "4"
        if state is "4":
            print "Scoop open. Sensing off."
            hunter.go_to_field()
            serial.change_state()
            egg_location = hunter.identify()
            print "Scoop Open. Enabling scoop sensing."
            state = serial.read()

        if state is "1":
            print "Scoop open. Sensing Enabled."
            hunter.go_to(egg_location)
            print "At egg location."
            state = serial.read()
            #self.position = basket

        if state is "2":
            print "Found egg! Scoop Closing. "
            state = serial.read()

        if state is "3":
            print "Scoop Closed. Ready to go home!"
            hunter.go_to_basket()
            print "At basket. Dropping egg."
            serial.change_state()
            state = serial.read()

        


