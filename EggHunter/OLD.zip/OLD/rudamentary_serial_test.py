import serial
import time

arduino = serial.Serial('/dev/ttyACM0', 9600, timeout=0.1 )

while True:
  time.sleep(1)
  data = arduino.readline()
  if  data:
    print "The Arduino sends: " + data.rstrip("\n")
    raw_input("Press enter to switch the Arduino's state.")
    arduino.write("a")
