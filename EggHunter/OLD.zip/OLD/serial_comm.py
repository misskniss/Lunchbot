#! /bin/bash/python

import serial 
import time

link = serial.Serial('/dev/ttyACM0', 9600)
link.isOpen()
time.sleep(1)
data = link.readline()
if data: 
    state = data.strip("\r\r\n")
    time.sleep(1)
    print state
count = 0
while (count < 10):
    if state is "4":
        print "Go to state 1"
        link.write("*")
        time.sleep(1)
        
        data = link.readline()
        time.sleep(1)
        if data: 
            state = data.strip("\r\r\n")
            time.sleep(1)
            print "new state: " + state

    if state is "2":
        print "State 2. Closing"
        time.sleep(1)
        
        data = link.readline()
        time.sleep(1)
        if data: 
            state = data.strip("\r\r\n")
            time.sleep(1)
            print "new state: " + state
    
    if state is "3":
        link.write("*")
        time.sleep(1)
        data = link.readline()
        time.sleep(1)
        if data: 
            state = data.strip("\r\r\n")
            time.sleep(1)
            print "new state: " + state
    count += 1

                

print "STOP"


