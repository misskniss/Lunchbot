import rospy
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats
import numpy
def listener():
    rospy.init_node('yoloswag')
    rospy.Subscriber("chatter1", String, callback1)
    rospy.Subscriber("chatter2", String, callback2)
    rospy.Subscriber("camera/depth/image", Image, callback3)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass

