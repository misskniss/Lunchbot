import rospy
from std_msgs.msg import String
import cv2
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
from sensor_msgs.msg import Image
xy=0.0
def callback1(data):
    global xy
    rospy.loginfo("Callback1 heard %s",data.data)
    rospy.loginfo(xy)

def callback2(data):
    global xy
    rospy.loginfo("Callback2 heard %s",data.data) 
    rospy.loginfo(xy)
    xy+=1
def callback3(data):
    """ This is a callback which recieves images and processes them. """
	# convert image into openCV format
    rospy.loginfo("LIFE IS SO HARD")
    bridge=CvBridge()
      # bgr8 is the pixel encoding -- 8 bits per color, organized as blue/green/red
    cv_imagepp = bridge.imgmsg_to_cv2(data)
    cv_image = cv_imagepp[288:480,0:640]   
    px=cv_image[100,420]
def listener():
    rospy.init_node('yoloswag')
    rospy.Subscriber("chatter1", String, callback1)
    rospy.Subscriber("chatter2", String, callback2)
    rospy.Subscriber("camera/depth/image", Image, callback3)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass

