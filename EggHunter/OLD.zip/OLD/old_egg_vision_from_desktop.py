#!/usr/bin/env python
""" 
  Example code of how to convert ROS images to OpenCV's cv::Mat

  See also cv_bridge tutorials: 
    http://www.ros.org/wiki/cv_bridge
    roslaunch turtlebot_bringup
    roslaunch openni_launch openni.launch
    rosrun image_viewe image.viewer
"""
import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from math import atan
import message_filters
xpx=0
ypx=0
px=0.0
# initialize a node called hw2
rospy.init_node("hw2")
# create a window to display results in
#cv2.createTrackbar("min", "Keypoints", 30, 300,nothing)
#cv2.createTrackbar("max", "Keypoints", 30, 300,nothing)
# part 2.1 of hw2 -- subscribe to a topic called image
image_rgb = rospy.Subscriber("camera/rgb/image_color", Image)
image_depth = rospy.Subscriber("camera/depth/camera", Image)
#self.image_sub=rospy.Subscriber("camera/depth/image", Image, self.callback)
def callback(rgb,depth):
  
    """ This is a callback which recieves images and processes them. """
	# convert image into openCV format
    bridge=CvBridge()
      # bgr8 is the pixel encoding -- 8 bits per color, organized as blue/green/red
    cv_imagepp = bridge.imgmsg_to_cv2(rgb)
    cv_imagezz = bridge.imgmsg_to_cv2(depth)
    cv_imagez = cv_imagepp[288:480,0:640]  
    cv_imagep = cv_imagepp[288:480,0:640]   
    #xconv=cv2.getTrackbarPos("min", "Keypoints")
    #yconv=cv2.getTrackbarPos("max", "Keypoints")
    params = cv2.SimpleBlobDetector_Params()

    params.filterByConvexity = True
    params.minConvexity = .73

    params.filterByArea = True
    params.minArea = 30 #should this be higher?
    
    params.filterByInertia = True
    params.minInertiaRatio = .1
    params.maxInertiaRatio = 1

    params.minThreshold = 110

    params.filterByCircularity = True
    params.minCircularity = .4

    ver = (cv2.__version__).split('.')
    if int(ver[0]) < 3:
        detector = cv2.SimpleBlobDetector(params)
    else:
	detector = cv2.SimpleBlobDetector_create(params)
    cv_imaged = cv2.GaussianBlur(cv_imagep,(5,5),0)
    cv_imageg = cv2. cvtColor(cv_imaged, cv2.COLOR_BGR2GRAY)
    detector=cv2.SimpleBlobDetector()    
    canny_img = cv2.Canny(cv_imaged,110,270)
#270 , 110
    keypoints=detector.detect(canny_img)
    test_with_keypoints= cv2.drawKeypoints(cv_imagep, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    cv2.imshow('Keypoints',test_with_keypoints)
    r=rospy.Rate(10)
    turn_cmd= Twist()
    start_time = rospy.get_time()
    time_now = rospy.get_time()
    try:
	self.xpx=keypoints[0].pt[0]
	self.ypx=keypoints[0].pt[1]
    	print('x: ',self.xpx)
        print("fuck")
	print('y: ',self.ypx)
        self.px=cv_imagez[self.xpx,self.ypx]
	print('DEPTH: ',self.px)
    except IndexError:
    	print("Cant find an egg")
        print("-1")
    #here    
    

    #here

    #cv2.imshow('Canny',canny_img)
    # show the image
    cv2.waitKey(5)
ts=message_filters.TimeSynchronizer([image_rgb, image_depth],10)
ts.registerCallback(callback)
rospy.spin()
