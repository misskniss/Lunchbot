#!/usr/bin/env python

# Author: Jen Kniss
# Date: March 2016
# Purpose: Controller class for running vision, navigation, and 
#          and serial communication to hunt for eggs on the blue turf

import ros
import roslaunch
import rospy
import roslib
import tf
import argparse
import actionlib
import get_position
import subprocess
import os
import serial
import time
from actionlib_msgs.msg import *
from EggVisionWIP import EggVisionWIP
from geometry_msgs.msg import Pose, PoseWithCovarianceStamped, Point, Quaternion, Twist
#from JensMoveIt import MoveIt
from MoveIt import MoveIt
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from nav_msgs.msg import Odometry
from serial_test import SerialTest
from sys import executable
from kobuki_msgs.msg import ButtonEvent


class EggHunter():

    def __init__(self, field, basket):

        self.FIELD_EDGE = field
        self.BASKET = basket
        self.MAX = 15.0
        print "Field location set to: " + str(self.FIELD_EDGE)
        print "Basket location set to: " + str(self.BASKET)

        self.kobuki = MoveIt()
        self.position = (0.0,0.0)

        #rospy.init_node('Egg_Hunt', anonymous=False)
        rospy.on_shutdown(self.shutdown)

    """
    def set_state(self, value):
        self.kobuki.set_state(value)
    """
    
    """ Handles the actual movement to a target
    """
    def go_to(self, target):
        print "Going to: " + str(target)
        self.kobuki.horizontal(target[0])
        self.kobuki.forward(target[1])
        x_val = self.position[0]
        x_val += target[0]
        y_val = self.position[1]
        y_val += target[1]
        self.position = (x_val, y_val)
        print "My position is now: " + str(self.position)
     
    """ Convenience method for going to the field.
        "Field" in this case just means ' clear the basket ' 
        so we are not detecting the egg we just put down. """
    def go_to_field(self):
        self.go_to_basket() # need this here? Put this here because "field"
                            # is just a new location in front of us...meant to 
                            # get us away from the basket so we don't pick up the 
                            # same egg
        print "Heading to field..." 
        self.go_to(self.FIELD_EDGE)
        print "At field."

    def go_to_edge_from_field(self):
        xtrup=self.FIELD_EDGE[0]-self.position[0]
        ytrup=self.FIELD_EDGE[1]-self.position[1]
        yoloswag=(xtrup,ytrup)
        self.go_to(yoloswag)
    
    """ Convenience method for going to the basket/home base. 
        "Basket" in this case means 'where ever she started.' """
    def go_to_basket(self):
        print "Calculating basket location..."
        #if self.postion != home...?
        x_val = self.position[0] * -1
        y_val = self.position[1] * -1
        new_target = (x_val, y_val)
        self.go_to(new_target)

        print "Heading to basket..."
        self.go_to(self.BASKET)
        print "At Basket."
    
    """ Uses the vision analysis instance to find
        a set of x,y distances from the center of the scoop in meters
        The center of the scoop on March 25th 2016 was 40 CM from the 
        front of the kinect."""
    def identify(self):
        
        print "Identifying... "
        ev = EggVisionWIP()
        distances = (-1,-1)
        r=rospy.Rate(10)
        time_start = rospy.get_time()
        time_now = rospy.get_time()
        
        print("Searching...")
        while (distances[0] == -1 and not rospy.is_shutdown()):    
            time_now=rospy.get_time()
            if (time_now-time_start > 10):
                # restart the current time after forward call & 10 seconds and 
                time_start=rospy.get_time() 
                print("No egg in sight, I'm outta here")
                # maintain 15 meter boundary
                if (self.position[1] + 0.5 < 15.0): 
                    halfMeter=(0.0,0.5)
                    self.go_to(halfMeter)
                else: 
                    # go back 10 meters and turn right 1 meter
                    # to check for new eggs in the location
                    wander=(1.0,-10.0)
                    self.go_to(wander)
            distances=ev.getDistance()
            r.sleep()

        print "New Deltas: " + str(distances)
        return distances

    def shutdown(self):
        rospy.loginfo("Stopping the hunt.")

    def dummy(ghggself, string):
        print string

if __name__ == '__main__':

    
    # These need to be coded for each environment as necessary
    field_edge = (0.0, 0.5)
    basket = (0.0, 0.0)
    egg_location = (0.0,0.0)
    position = (0.0, 0.0)
    #rospy.init_node('Egg_Hunt', anonymous=False)
    
    hunter = EggHunter(field_edge, basket)
    serial = SerialTest()

    state = serial.read() # will read state 4 or 44 (if stacked up)
    print "Start. State is: " + state
    while (state != None):
        if state is "44":
            state = "4"

        if state is "4":
            print "In state " + state
            print "Scoop open. Sensing off."
            hunter.go_to_field()
            serial.change_state()
            egg_location = hunter.identify()
            print "Scoop Open. Enabling scoop sensing."
            #state = serial.read()
            hunter.go_to(egg_location)
            test2=serial.read()
            if(test2==None):
                state="1"
            else:
                state=test2

        if state is "1":
            print "Went to egg location but did not manage to grab an egg, retrying..."
            print "state 1 atm"
            hunter.go_to_edge_from_field()
            egg_location=hunter.identify()
            hunter.go_to(egg_location)
            tester = serial.read()
            if tester!=None:
                state=tester

        """if state is "2":
            print "Found egg! Scoop Closing. "
            state = serial.read()"""

        if (state is "2") or (state is "3") or (state is "12"):
            print "state 2 or 3 atm"
            print "Scoop Closed. Ready to go home!"
            hunter.go_to_basket()
            print "At basket. Dropping egg."
            serial.change_state()
            state = serial.read()
    print("There is no state, yay time to restart!")
