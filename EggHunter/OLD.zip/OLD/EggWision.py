""" 
  Example code of how to convert ROS images to OpenCV's cv::Mat
  See also cv_bridge tutorials: 
    http://www.ros.org/wiki/cv_bridge
    roslaunch turtlebot_bringup
    roslaunch openni_launch openni.launch
    rosrun image_viewe image.viewer
"""
import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from math import atan, pow, sqrt, sin, cos
#from std_msgs.msg import Float32MultiArray
xpx=0
ypx=0
px=0.0
def listener():
    # initialize a node called hw2
    rospy.init_node("hw2")
    #pub = rospy.Publisher('EggVision', Float32MultiArray)
    #pub.publish(getDistance())
    #Maybe I have to make this an array, test it out
    #Optimize the threshold for the BSU Turf
    # create a window to display results in
    cv2.namedWindow("Canny", 1)
    cv2.namedWindow("Image", 1)
    #cv2.createTrackbar("min", "Keypoints", 30, 300,nothing)
    #cv2.createTrackbar("max", "Keypoints", 30, 300,nothing)
    # part 2.1 of hw2 -- subscribe to a topic called image
    rospy.Subscriber("camera/rgb/image_color", Image, callback1)
    rospy.Subscriber("camera/depth/image", Image, callback2)
    #self.image_sub=rospy.Subscriber("camera/depth/image", Image, self.callback)
def callback2(data):
    global xpx
    global ypx
    global px
    """ This is a callback which recieves images and processes them. """
	# convert image into openCV format
    bridge=CvBridge()
      # bgr8 is the pixel encoding -- 8 bits per color, organized as blue/green/red
    cv_imagepp = bridge.imgmsg_to_cv2(data)
    cv_image = cv_imagepp[288:480,0:640]
    if(xpx!=0):   
        px=cv_image[ypx,xpx]

def callback1(data):
    global xpx
    global ypx
    global px
    """ This is a callback which recieves images and processes them. """
	# convert image into openCV format
    bridge=CvBridge()
      # bgr8 is the pixel encoding -- 8 bits per color, organized as blue/green/red
    cv_imagepp = bridge.imgmsg_to_cv2(data)
    cv_imagep = cv_imagepp[288:480,0:640]   
    #xconv=cv2.getTrackbarPos("min", "Keypoints")
    #yconv=cv2.getTrackbarPos("max", "Keypoints")
    params = cv2.SimpleBlobDetector_Params()

    params.filterByConvexity = True
    params.minConvexity = .73

    params.filterByArea = True
    params.minArea = 30 #should this be higher?
    
    params.filterByInertia = True
    params.minInertiaRatio = .1
    params.maxInertiaRatio = 1

    params.minThreshold = 110

    params.filterByCircularity = True
    params.minCircularity = .4

    ver = (cv2.__version__).split('.')
    if int(ver[0]) < 3:
        detector = cv2.SimpleBlobDetector(params)
    else:
	detector = cv2.SimpleBlobDetector_create(params)
    cv_imaged = cv2.GaussianBlur(cv_imagep,(5,5),0)
    cv_imageg = cv2. cvtColor(cv_imaged, cv2.COLOR_BGR2GRAY)
    detector=cv2.SimpleBlobDetector()    
    canny_img = cv2.Canny(cv_imaged,110,270)
    #270 , 110
    keypoints=detector.detect(canny_img)
    test_with_keypoints= cv2.drawKeypoints(cv_imagep, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    test_with_stuff= cv2.drawKeypoints(canny_img, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    cv2.imshow('Image',test_with_keypoints)
    cv2.imshow('Canny',test_with_stuff)
    r=rospy.Rate(50000)
    start_time = rospy.get_time()
    time_now = rospy.get_time()
    try:
	xpx=keypoints[2].pt[0]
	ypx=keypoints[2].pt[1]
	print("We got rare peep!")
	cv2.waitKey(100000)
    except IndexError:
	print("...")
    print("THIS IS THE END %d",getDistance())
    cv2.waitKey(5)
def getDistance():
    if (px!=0.0 and xpx!=0 and ypx!=0):
        flatDepth=sqrt(pow(px,2)-pow(.27,2))
        #Subtracted horizontal pixels from center and divided it by 640 to get ratio to screen
        #Then multiplied by 57 degrees to get total turn angle in degrees, converted to rads.
	magicAngle=3.1416*57*(xpx-320)/115200
        if (magicAngle < 0):
            magicAngle=abs(magicAngle)
	    xdist=-1*flatDepth*sin(magicAngle)
	else:
	    xdist=flatDepth*sin(magicAngle)
        magicAngle=abs(magicAngle)
        #EDIT THIS AFTER ROBERT INSTALLS CLAW SO WE CAN SEE OFFSET FROM KINECT SENSOR TO FRONT OF CLAW, SIMPLY SUBTRACT THE YDIST FROM OFFSET
	ydist=flatDepth*cos(magicAngle)
        return (xdist, ydist)
    else:
	return (-1,-1)
	    

if __name__ == '__main__':
    listener()
    try:  
        rospy.spin()
    except KeyboardInterrupt:
        print "Shutting down"
    cv2.destroyAllWindows()
