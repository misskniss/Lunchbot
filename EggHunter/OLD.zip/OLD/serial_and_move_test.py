#! /bin/bash/python
from JensMoveIt import MoveIt
from serial_test import SerialTest

# Author: Jen Kniss
# Date: March 2016
# Purpose: Test the integration of the seial and kobuki controls

class SerialMoveTest():

    FWD = 0.5
    RL = 0.5

    def __init__(self):
        serial = SerialTest()
        kobuki = MoveIt()

        state = serial.read()
        print "In state " + state

        while(state != None):
            if state is "4":
                print "Egg delivered. Open. No Sensing."
                kobuki.forward(self.FWD)
                print "At Field. Changing state to 1."
                serial.change_state()
                state = serial.read()

            if state is "1":
                print "Going to an egg."
                kobuki.forward(self.FWD)
                kobuki.horizontal(self.RL)
                print "Should have an egg?"
                state = serial.read()

            if state is "2":
                kobuki.stop()
                print "Scooping an egg."
                state = serial.read()

            if state is "3":
                print "We have an egg! Ready to go home."
                kobuki.horizontal(-self.RL)
                kobuki.forward(-self.FWD)
                print "We should be home. Dropping egg."
                serial.change_state()
                state = serial.read()

    
if __name__ == '__main__':
    serial_and_move = SerialMoveTest()


