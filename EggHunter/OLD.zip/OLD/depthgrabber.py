#!/usr/bin/env python
""" 
  Example code of how to convert ROS images to OpenCV's cv::Mat

  See also cv_bridge tutorials: 
    http://www.ros.org/wiki/cv_bridge
    roslaunch turtlebot_bringup
    roslaunch openni_launch openni.launch
    rosrun image_viewe image.viewer
"""
import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from math import atan
def nothing(x):
    pass
class canny_egg_detection:

  def __init__(self):
    # initialize a node called hw3
    rospy.init_node("hw3")
    self.image_sub = rospy.Subscriber("camera/depth/camera", Image, self.callback)

  def callback(self,data):
    """ This is a callback which recieves images and processes them. """
	# convert image into openCV format
    bridge=CvBridge()
      # bgr8 is the pixel encoding -- 8 bits per color, organized as blue/green/red
    cv_imagepp = bridge.imgmsg_to_cv2(data)
    cv_image = cv_imagepp[288:480,0:640]   
    px=cv_image[96,320]
    cv2.imshow("test",cv_image)
    print(px)
    cv2.waitKey(5)


if __name__ == '__main__':
    canny_egg_detection()
    try:  
        rospy.spin()
    except KeyboardInterrupt:
        print "Shutting down"
    cv2.destroyAllWindows()

