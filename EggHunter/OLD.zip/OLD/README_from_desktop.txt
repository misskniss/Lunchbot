﻿README 
EGG DETECTION SOFTWARE 
AUTHORS: HAYDEN MILLS, KEVIN JINN 
NECESSARY FILES: Egg_Vision.py
2016 


This README will instruct you on the proper way to execute the python code for this program. This README will NOT show you how to connect to the robot, only on properly getting this software to work over an SSH connection. 
 
Steps: 
0. Ensure that four terminal/konsole windows are running and connected to the turtlebot. Three of these windows will be used in the proper startup of the robot and the various components connected to it.

1. In the first command window run roslaunch turtlebot_bringup minimal.launch this command will start a compatibility check with the robot, to ensure that all of the robots capabilities are working. These components include but are not limited to: RGBD Sensors, LED lights, robot bumpers, and input ports. If this step works without any red texts(red texts indicates an error) than proceed to step 2. If red texts is produced, than leave the step section and proceed to the TROUBLESHOOTING section.

2. In the second terminal window run roslaunch openni_launch openni.launch this will verify that all the camera drivers are working properly and will also ensure the ros is also working correctly. If this step is working proceed to step 3.  If this step works without any red texts(red indicates an error) than proceed to step 3. If red texts is produced, than leave the step section and proceed to the TROUBLESHOOTING section.

3. The final step will be to activate the image finding software. To run this, find the necessary python file and then run python Egg_Vision.py which will use the python compiler to run the code specified. Have fun finding easter eggs!


TROUBLESHOOTING:
If an error is produced, such as red text, there are two steps to resolve the error.
1. Verify that the connection to the kinect has been made by running the following command in a terminal session rosrun image.viewer if a video feed of the kinect can been seen, then a simple closing of all terminals and restarting the steps section is needed. However, if an error is produced OR no video can be seen. The turtle bot computer will need to be restarted. Once the restart has been made, proceed to the steps section.
