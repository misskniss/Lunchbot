import rospy
from serial_test import SerialTest
import serial
def listener():
    rospy.init_node("testnode")
    serial=SerialTest()
    state=serial.read()
    print("start state"+state)
    serial.change_state()
    state=serial.read()
    print("canged state"+state)
if __name__ == '__main__':
    listener()
