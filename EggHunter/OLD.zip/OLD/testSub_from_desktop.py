import rospy
from std_msgs.msg import Float32MultiArray

def callback1(data):
    rospy.loginfo("Callback1 heard %s",data.data)
def listener():
    rospy.init_node('yoloswag')
    rospy.Subscriber("chatter1", Float32MultiArray, callback1)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
if __name__ == '__main__':
  listener()
  try:  
        rospy.spin()
    except KeyboardInterrupt:
        print "Shutting down"

