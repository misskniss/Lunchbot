#! /bin/bash/python

# Author: Kevin Jin
# Date: March 2016
# Purpose: For non-map based control of Kobuki base

import rospy
from geometry_msgs.msg import Twist


""" This the class that moves the Kobuki base according to a passed x and y 
    value. 
"""
class MoveIt():
    
    ANGULAR = 0.3925
    LINEAR = 0.0
    RATE = 100
    TIME_BASE = 5.5
    MIN_X = 0.0
    INCR_X = 0.1
    MIN_Z = 0.0
    Y_MULT = 10

    #Kevin: I get the following error when I run this:
    """
    File "/home/lunchbot/Desktop/ECE474/MoveIt.py", line 34, in forward
    
    r = rospy.Rate(self.RATE)
    File "/opt/ros/indigo/lib/python2.7/dist-packages/rospy/timer.py", line 59, in __init__
    self.last_time = rospy.rostime.get_rostime()
    File "/opt/ros/indigo/lib/python2.7/dist-packages/rospy/rostime.py", line 209, in get_rostime
    raise rospy.exceptions.ROSInitException("time is not initialized. Have you called init_node()?")
    rospy.exceptions.ROSInitException: time is not initialized. Have you called init_node()?
    """

    
    """ Go y-dist forward in meters
    """

    def forward(self, ydist):
        
        self.cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
        move_cmd = Twist()
        r = rospy.Rate(self.RATE)
        move_cmd.linear.x = self.INCR_X
        ydist = ydist * self.Y_MULT
        move_cmd.angular.z = self.MIN_Z
        start_time=rospy.get_time()
        time_now=rospy.get_time()
        
        while (time_now-start_time < ydist): 
            self.cmd_vel.publish(move_cmd)
            time_now=rospy.get_time()
            r.sleep()
        move_cmd.linear.x = self.MIN_X
    
    """ Go x-dist left/right in meters
    """
    def horizontal(self, xdist):
     	  
          if (xdist > self.MIN_X):
     	      self.turnRight()
     	      self.forward(xdist)
     	      self.turnLeft()
     	  else:
     	      self.turnLeft()
              xdist = abs(xdist)
     	      self.forward(xdist)
     	      self.turnRight()
     	    
    """ 
    """
    def turnRight(self):
     	  cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
     	  move_cmd = Twist()
     	  r = rospy.Rate(self.RATE)
     	  move_cmd.angular.z = self.ANGULAR
     	  move_cmd.linear.x = self.MIN_X
     	  start_time=rospy.get_time()
          time_now=rospy.get_time()

          while (time_now-start_time < self.TIME_BASE): 
              cmd_vel.publish(move_cmd)
              time_now=rospy.get_time()
              r.sleep()
          move_cmd.angular.z = self.MIN_Z
    
    """
    """
    def turnLeft(self):
     	  cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
     	  move_cmd = Twist()
     	  r = rospy.Rate(self.RATE)
     	  move_cmd.angular.z = -self.ANGULAR
     	  move_cmd.linear.x = self.MIN_X
     	  start_time=rospy.get_time()
          time_now=rospy.get_time()

          while (time_now-start_time < self.TIME_BASE): 
              cmd_vel.publish(move_cmd)
              time_now=rospy.get_time()
              r.sleep()
          move_cmd.angular.z = self.MIN_Z

    """
    """
    def stop(self):
        print "STOP"        

