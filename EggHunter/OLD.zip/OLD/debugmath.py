math=5*(200-428)*3.1416/180
math=abs(math)
print(math)
