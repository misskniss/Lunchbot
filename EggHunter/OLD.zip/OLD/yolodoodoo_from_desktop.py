#!/usr/bin/env python
""" 
  Example code of how to convert ROS images to OpenCV's cv::Mat

  See also cv_bridge tutorials: 
    http://www.ros.org/wiki/cv_bridge
    roslaunch turtlebot_bringup
    roslaunch openni_launch openni.launch
    rosrun image_viewe image.viewer
"""
import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
def nothing(x):
    pass
class canny_egg_detection:

  def __init__(self):
    # initialize a node called hw2
    rospy.init_node("hw2")

    # create a window to display results in
    cv2.namedWindow("Keypoints", 1)
    cv2.createTrackbar("min", "Keypoints", 30, 300,nothing)
    cv2.createTrackbar("max", "Keypoints", 30, 300,nothing)
    # part 2.1 of hw2 -- subscribe to a topic called image
    self.image_sub = rospy.Subscriber("camera/rgb/image_color", Image, self.callback)

  def callback(self,data):
    """ This is a callback which recieves images and processes them. """
    self.cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
   # COVERT_TO_RADIAN=3.141592/180.0
	# convert image into openCV format
    #goodornot=True
    bridge=CvBridge()
      # bgr8 is the pixel encoding -- 8 bits per color, organized as blue/green/red
    cv_imagepp = bridge.imgmsg_to_cv2(data)
    cv_imagep = cv_imagepp[288:480,0:640]
    #uncomment this if you want to see the live feed
    #cv2.imshow("image_view",cv_image)   
    xconv=cv2.getTrackbarPos("min", "Keypoints")
    yconv=cv2.getTrackbarPos("max", "Keypoints")
    params = cv2.SimpleBlobDetector_Params()

    params.filterByConvexity = True
    params.minConvexity = .73

    params.filterByArea = True
    params.minArea = 30
    
    params.filterByInertia = True
    params.minInertiaRatio = .1
    params.maxInertiaRatio = 1

    params.minThreshold = xconv

    params.filterByCircularity = True
    params.minCircularity = .4

    ver = (cv2.__version__).split('.')
    if int(ver[0]) < 3:
        detector = cv2.SimpleBlobDetector(params)
    else:
	detector = cv2.SimpleBlobDetector_create(params)
    cv_imaged = cv2.GaussianBlur(cv_imagep,(3,3),0)
    cv_imageg = cv2. cvtColor(cv_imaged, cv2.COLOR_BGR2GRAY)
    detector=cv2.SimpleBlobDetector()    
    canny_img = cv2.Canny(cv_imaged,270,110)
    keypoints=detector.detect(canny_img)
    
    test_with_keypoints= cv2.drawKeypoints(cv_imagep, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    cv2.imshow('Keypoints',test_with_keypoints)
    #here    
    turn_cmd= Twist()
    turn_cmd.angular.z = 2
    start_time = rospy.get_time()
    time_now = rospy.get_time()
    while (time_now-start_time < 2.0):
        self.cmd_vel.publish(turn_cmd)
        time_now=rospy.get_time()
    #here

    #cv2.imshow('Canny',canny_img)
    # show the image
    cv2.waitKey(5)


if __name__ == '__main__':
    canny_egg_detection()
    try:  
        rospy.spin()
    except KeyboardInterrupt:
        print "Shutting down"
    cv2.destroyAllWindows()
