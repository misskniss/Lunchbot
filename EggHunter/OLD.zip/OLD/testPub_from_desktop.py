import rospy
from rospy.numpy_msg import numpy_msg
from rospy_tutorials.msg import Floats

import numpy
def talker():
    pub = rospy.Publisher('yoloswag', numpy_msg(Floats),queue_size=10)
    rospy.init_node('talker', anonymous=True)
    r = rospy.Rate(10) # 10hz
    a = numpy.array([1.0, 2.1, 3.2, 4.3, 5.4, 6.5], dtype=numpy.float32)
    rospy.loginfo("LIFE IS SO HARD")
    pub.publish(a)
    r.sleep()
    rospy.spin()

if __name__ == '__main__':
    try:
	talker()
    except KeyboardInterrupt:
	print "SHGUTTTTTTT DOWNNNNNNNNNNNNNNNNNNNNNNNnn!"
