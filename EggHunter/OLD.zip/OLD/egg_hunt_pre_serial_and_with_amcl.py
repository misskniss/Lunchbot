#!/usr/bin/env python

import ros
import roslaunch
import rospy
import roslib
import tf
import argparse
import actionlib
import subprocess
import os
import serial
import time
from EggVisionWIP import EggVisionWIP
#from go_to import GoTo
from MoveIt import MoveIt
import get_position
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import *
from geometry_msgs.msg import Pose, PoseWithCovarianceStamped, Point, Quaternion, Twist
from nav_msgs.msg import Odometry
from sys import executable


class EggHunter():

    def __init__(self, field, basket):

        self.DETECT = 1
        self.DROP = 0
        self.FIELD_EDGE = field
        self.BASKET = basket
        self.position = (-20,-20,0)
        print self.FIELD_EDGE
        print self.BASKET
        try: 
            self.link = serial.Serial('/dev/ttyACM0', 9600)
        except:
            self.link = serial.Serial('/dev/ttyACM1', 9600)

        self.link.isOpen()
        self.state = self.link.read(self.link.inWaiting())
        
        rospy.init_node('Egg_Hunt', anonymous=False)
        rospy.on_shutdown(self.shutdown)
    
    def go_to_field(self):
        self.go_to(self.FIELD_EDGE)
        print "At field."

    def hunt(self):
        ###self.go_to_field()
        print "Move."
        self.detect_egg()
        self.fetch_egg()
        self.go_home()
        self.drop_egg()

    def detect_egg(self):
        self.link.write("*")
        time.sleep(3)
        self.state = self.link.read(self.link.inWaiting())
        self.identify()
        self.set_scooper_state(self.DETECT)
        print "Scoop is detecting eggs."
    
    def fetch_egg(self):
        self.go_to(self.get_egg_location())
        print "Fetching Egg..."
    
    def go_home(self):
        self.go_to(self.BASKET)
        print "At Basket."
    
    def drop_egg(self):
        self.link.write("*")
        time.sleep(3)
        self.state = self.link.read(self.link.inWaiting())
        self.set_scooper_state(self.DROP)
        print "Egg in basket."
    
   
    def go_to(self, target):
        now = self.get_my_position()
        print "I am at: " + str(now)
        
        """ The following runs the go_to sctipt created by 
            Jen for handling targets with a separate node.
        """
        print "Moving to " + str(tuple(target))
        x, y, z = target
        args = "" + str(x) + " " + str(y) + " " + str(z) + ""
        command = "python go_to.py " + args
        print "Command: " + command
        os.system(command)
    
    def identify(self):
        print "Identifying... "
        ev = EggVisionWIP()
        distances = (-1,-5)
        r=rospy.Rate(10)
        while (distances[0]==-1 and not rospy.is_shutdown()):
            distances = ev.getDistance()
            print("Searching...")    
            r.sleep()
        #print "Kevins: " + str(tuple(values))
        print "Deltas: " + str(distances)
        #return (-3, 2)  # Represents egg is 3ft to the left and 2 feet forward

    def translate(self, current_position, vision_results):
        #new_coordinates = my current position + distances for x and y

        print "Translating distances" + str(tuple(vision_results)) + " with current pose " + str(tuple(current_position))
        fake_new_coordinates =(0.0, 0.0, 0.0)
        return fake_new_coordinates
    
    def set_scooper_state(self, state):
        # send a signal to the scoop to indicate travelling or ready to hunt
        # call a function from Robert's code that will do this:
        # Scooper.set_state(state)
        if (state is self.DROP):
            print "Setting Scoop state to DROP"
        elif (state is self.DETECT):
            print "Setting Scoop to DETECT"
        else:
            print "Unknown scoop state. Ignoring request."

    def positionIs(self, msg):
        self.position = msg.pose.pose.position
        self.my_x = self.position.x
        self.my_y = self.position.y
        self.my_z = self.position.z
        sub_obj.unregister()
        return (self.my_x, self.my_y, self.my_z)
        

    def get_my_position(self):
        global sub_obj
        sub_obj = rospy.Subscriber('odom', Odometry, self.positionIs)
        ##self.position = rospy.wait_for_message('odom/pose/pose/position/x', Odometry, 10)
        time.sleep(5)
        return (self.my_x, self.my_y, self.my_z)

    def get_egg_location(self):
        #my_pose = self.get_my_position()
        x,y,z = self.get_my_position()
        print "My pose is: "
        #my_point = (my_pose.x, my_pose.y, my_pose.z)
        my_point = (x, y, z)
        print my_point.x, my_point.y, my_point.z
        distances = self.identify()
        egg_location = self.translate(my_point, distances)
        print "Found egg location."
        return egg_location

    def shutdown(self):
        rospy.loginfo("Stopping the hunt.")

    def dummy(self, string):
        print string

if __name__ == '__main__':
    
    # These need to be coded for each map you make
    field_edge = (-1.0, 1.0, 0.5)
    basket = (0.66, 0.66, 0.5)
    
    hunter = EggHunter(field_edge, basket)
    hunter.hunt()

